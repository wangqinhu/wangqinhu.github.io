1. 将Ruijie Supplicant和MacRJ拖入Applications
2. 连接网卡（有线或者无线）
3. 在应用程序里点击MacRJ，并输入密码，确定后将弹出锐捷客户端，设定好即可联网
4. 如有洁癖，连接成功后可将MacRJ退出

By Wang Qinhu (qinhu.wang@gmail.com)

2013-11-01
